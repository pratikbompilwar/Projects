﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BerlinClock
{
    public class TimeConverter : ITimeConverter
    {
        public string convertTime(string aTime)
        {            
            int hours = Int32.Parse(aTime.Split(':').First());
            if(hours >24)
            {
                throw new Exception("Incorrect input for Berlin Clock");
            }
            int minutes = Int32.Parse(aTime.Substring(3, 2));
            if (minutes > 59)
            {
                throw new Exception("Incorrect input for Berlin Clock");
            }
            int seconds = Int32.Parse(aTime.Substring(6, 2));
            if (seconds > 59)
            {
                throw new Exception("Incorrect input for Berlin Clock");
            }
            string output = GetBerlinClock(hours,minutes,seconds);
            return output;           
        }

        /// <summary>
        /// Function to get Berlin clock display string
        /// </summary>
        /// <param name="Hours">Number of hours</param>
        /// <param name="Minutes">Number of minutes</param>
        /// <param name="Seconds">Number of seconds</param>
        /// <returns>Berlin Clock in strings</returns>
        private string GetBerlinClock(int Hours, int Minutes, int Seconds)
        {
            StringBuilder berlinClock = new StringBuilder();
            int firstRowLamps = Hours/5;
            int secondRowLamps = Hours % 5;
            int thirdRowLamps = Minutes/5;
            int forthRowLamps = Minutes % 5;
            string seconds = Seconds % 2 == 0 ? "Y" : "O";

            berlinClock.Append(seconds + "\r\n");
            berlinClock.Append(GetHourLamps(4, firstRowLamps,(4-firstRowLamps)) +"\r\n"+ GetHourLamps(4, secondRowLamps, (4 - secondRowLamps)) + "\r\n");
            berlinClock.Append(GetMinutesLamps(11, thirdRowLamps, (11 - firstRowLamps)) + "\r\n" + GetMinutesLamps(4, forthRowLamps, (4 - forthRowLamps)));



            return berlinClock.ToString();
        }

        /// <summary>
        /// Function to get Hour Lamps
        /// </summary>
        /// <param name="TotalLamps">Total number of Lamps</param>
        /// <param name="TotalOnLamps">Total number of ON lamps</param>
        /// <param name="TotalOffLamps">Total number of OFF lamps</param>
        /// <returns>Hour Lamps</returns>
        private string GetHourLamps(int TotalLamps, int TotalOnLamps, int TotalOffLamps)
        {
            StringBuilder lamps = new StringBuilder();
            for(int i=1;i<=TotalLamps;i++)
            {
                if (i <= TotalOnLamps)
                {
                    lamps.Append("R");
                }
                else
                {
                    lamps.Append("O");
                }
            }
            return lamps.ToString();
        }

        /// <summary>
        /// Fuction to get Minute Lamps
        /// </summary>
        /// <param name="TotalLamps">Total number of Lamps</param>
        /// <param name="TotalOnLamps">Total number of ON lamps</param>
        /// <param name="TotalOffLamps">Total number of OFF lamps</param>
        /// <returns>Minues Lamps</returns>
        private string GetMinutesLamps(int TotalLamps, int TotalOnLamps, int TotalOffLamps)
        {
            StringBuilder lamps = new StringBuilder();
            for (int i = 1; i <= TotalLamps; i++)
            {
                if (i <= TotalOnLamps)
                {
                    if (i % 3 == 0 && TotalLamps == 11)
                    {
                        lamps.Append("R");
                    }
                    else
                    {
                        lamps.Append("Y");
                    }
                }
                else
                {
                    lamps.Append("O");
                }
            }
            return lamps.ToString();
        }
    }
}
